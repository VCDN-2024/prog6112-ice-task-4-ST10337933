package icetask4;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

// Base class for Person
class Person {
    protected String firstName;
    protected String lastName;
    protected String streetAddress;
    protected String zipCode;
    protected String phoneNumber;

    // Method to set Person's information
    public void setPersonInfo() {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Enter first name: ");
        this.firstName = scanner.nextLine();

        System.out.print("Enter last name: ");
        this.lastName = scanner.nextLine();

        System.out.print("Enter street address: ");
        this.streetAddress = scanner.nextLine();

        System.out.print("Enter zip code: ");
        this.zipCode = scanner.nextLine();

        System.out.print("Enter phone number: ");
        this.phoneNumber = scanner.nextLine();
    }

    // Method to display Person's information
    public void displayInfo() {
        System.out.println(firstName + " " + lastName + ", " + streetAddress + ", " + zipCode + ", " + phoneNumber);
    }
}

// Class for Hospital Staff
class HospitalStaff extends Person {
    private String staffId;
    private double annualSalary;
    private String department;

    // Method to set HospitalStaff's information
    @Override
    public void setPersonInfo() {
        super.setPersonInfo(); // Set Person info

        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Enter staff ID: ");
        this.staffId = scanner.nextLine();

        System.out.print("Enter annual salary: ");
        this.annualSalary = scanner.nextDouble();
        scanner.nextLine(); // Consume newline

        System.out.print("Enter department: ");
        this.department = scanner.nextLine();
    }

    // Method to display HospitalStaff's information
    @Override
    public void displayInfo() {
        super.displayInfo(); // Display Person info
        System.out.println("Staff ID: " + staffId + ", Annual Salary: " + annualSalary + ", Department: " + department);
    }
}

// Class for Doctor
class Doctor extends HospitalStaff {
    private boolean isSpecialist;

    // Method to set Doctor's information
    @Override
    public void setPersonInfo() {
        super.setPersonInfo(); // Set HospitalStaff info

        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Is the doctor a specialist? (true/false): ");
        this.isSpecialist = scanner.nextBoolean();
    }

    // Method to display Doctor's information
    @Override
    public void displayInfo() {
        super.displayInfo(); // Display HospitalStaff info
        System.out.println("Is Specialist: " + (isSpecialist ? "Yes" : "No"));
    }
}

// Class for Patient
class Patient extends Person {
    private String medicalRecordNumber;
    private List<String> currentAilments;

    public Patient() {
        currentAilments = new ArrayList<>();
    }

    // Method to set Patient's information
    @Override
    public void setPersonInfo() {
        super.setPersonInfo(); // Set Person info

        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Enter medical record number: ");
        this.medicalRecordNumber = scanner.nextLine();

        System.out.print("Enter current ailments (comma-separated): ");
        String ailments = scanner.nextLine();
        String[] ailmentsArray = ailments.split(",");
        for (String ailment : ailmentsArray) {
            currentAilments.add(ailment.trim());
        }
    }

    // Method to display Patient's information
    @Override
    public void displayInfo() {
        super.displayInfo(); // Display Person info
        System.out.println("Medical Record Number: " + medicalRecordNumber + ", Current Ailments: " + currentAilments);
    }
}

// Main class for Hospital Management
public class Icetask4 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        HospitalStaff[] staffArray = new HospitalStaff[4];
        Doctor[] doctorArray = new Doctor[3];
        Patient[] patientArray = new Patient[7];

        int staffCount = 0, doctorCount = 0, patientCount = 0;

        while (true) {
            System.out.print("Enter type of person (H for Hospital Staff, D for Doctor, P for Patient, Q to Quit): ");
            String input = scanner.nextLine().toUpperCase();

            if (input.equals("Q")) {
                break;
            }

            switch (input) {
                case "H":
                    if (staffCount < 4) {
                        staffArray[staffCount] = new HospitalStaff();
                        staffArray[staffCount].setPersonInfo();
                        staffCount++;
                    } else {
                        System.out.println("Error: Cannot enter more than 4 Hospital Staff.");
                    }
                    break;

                case "D":
                    if (doctorCount < 3) {
                        doctorArray[doctorCount] = new Doctor();
                        doctorArray[doctorCount].setPersonInfo();
                        doctorCount++;
                    } else {
                        System.out.println("Error: Cannot enter more than 3 Doctors.");
                    }
                    break;

                case "P":
                    if (patientCount < 7) {
                        patientArray[patientCount] = new Patient();
                        patientArray[patientCount].setPersonInfo();
                        patientCount++;
                    } else {
                        System.out.println("Error: Cannot enter more than 7 Patients.");
                    }
                    break;

                default:
                    System.out.println("Invalid input. Please enter H, D, P, or Q.");
                    break;
            }
        }

        // Display report
        System.out.println("\nHospital Staff:");
        if (staffCount == 0) {
            System.out.println("No Hospital Staff data entered.");
        } else {
            for (int i = 0; i < staffCount; i++) {
                staffArray[i].displayInfo();
            }
        }

        System.out.println("\nDoctors:");
        if (doctorCount == 0) {
            System.out.println("No Doctor data entered.");
        } else {
            for (int i = 0; i < doctorCount; i++) {
                doctorArray[i].displayInfo();
            }
        }

        System.out.println("\nPatients:");
        if (patientCount == 0) {
            System.out.println("No Patient data entered.");
        } else {
            for (int i = 0; i < patientCount; i++) {
                patientArray[i].displayInfo();
            }
        }

        // Close the scanner
        scanner.close();
    }
}
